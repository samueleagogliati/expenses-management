const knexConfig = {
    client: 'mysql',
    connection: {
      host: 'localhost',
      user: 'id22001783_samueleago',
      password: 'Tshaba14-',
      database: 'id22001783_calendar'
    }
  }
export default knexConfig
  